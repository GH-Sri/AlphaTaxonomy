# rds_config.py

db_username = 'mdas'
db_password = 'mdaspassword'
db_name = 'mdas'
